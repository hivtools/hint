library(testthat)
library(hintr)

test_check("hintr")
