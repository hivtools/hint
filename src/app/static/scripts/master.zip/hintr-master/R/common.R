## This file contains "hintr constants"
QUEUE_CALIBRATE <- "calibrate"
QUEUE_RUN <- "run"
PROJECT_STATE_PATH <- file.path("info", "project_state.json")
NOTES_PATH <- "notes.txt"
INDICATORS_PATH <- "indicators.csv"
