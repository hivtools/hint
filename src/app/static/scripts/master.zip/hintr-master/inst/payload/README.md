# Payloads

These are example payloads for sending to the API. Some of these are templates and need to have additional info e.g. version added to work. To generate a payload with the latest version use the `setup_payload_*` functions from `R/payload_helpers.R`.
